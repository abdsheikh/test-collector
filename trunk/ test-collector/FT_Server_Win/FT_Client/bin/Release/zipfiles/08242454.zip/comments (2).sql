-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 01, 2011 at 07:53 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Email` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `CommentText` text CHARACTER SET utf8,
  `CommentSubject` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `CommentDate` datetime DEFAULT NULL,
  `TitleID` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=35 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `FullName`, `Email`, `CommentText`, `CommentSubject`, `CommentDate`, `TitleID`) VALUES
(30, 'xin chao', 'conduongngayxua1990@gmail.com', 'vì m?t', 'hau ', '2011-11-21 00:00:00', 0),
(31, 'duongnguyen', 'conduongngayxua1990@gmail.com', 'mámkwal', 'nsns', '2011-11-29 00:00:00', 0),
(32, 'duong', 'conduongngayxua1990@gmail.com', 'nnsnsm', 'mmsms', '2011-11-30 00:00:00', 0),
(33, 'duongnguyen', 'conduongngayxua1990@gmail.com', 'Th?t h?nh phúc ??n ch?y n??c m?t khi ??c ???c nh?ng dòng này, T? Qu?c là thiêng liêng và b?t kh? xâm ph?m t? ngàn ??i nay mà cha ông ta ?ã hy sinh và gìn gi?, ngày nay các th? h? s? ti?p b??c, tôi ?ng h? Th? T??ng v? v?n ?? này và s? l?i c?m súng khi T? Qu?c c?n!', 'C?m ?n Th? T??ng', '2011-11-30 00:00:00', 0),
(34, 'sao ta', 'conduongngayxua1990@gmail.com', 'nnss', 'coi thu coi', '2011-11-30 00:00:00', 0);
